package com.cg.mobilebilling.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.mobilbilling.pagebeans.GetPostpaidAccountDetailsPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PostpaidAccountDetailsStepDefinition {
	private WebDriver driver;
	private GetPostpaidAccountDetailsPage postpaidAccountPage;
	@Given("^User is on postpaid account details page$")
	public void user_is_on_postpaid_account_details_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:4444/postpaidAccountDetails");
		postpaidAccountPage=PageFactory.initElements(driver,GetPostpaidAccountDetailsPage.class);
	}

	@When("^User enters correct customer id and mobile number$")
	public void user_enters_correct_customer_id_and_mobile_number() throws Throwable {
		postpaidAccountPage.setCustomerID("1002");
		postpaidAccountPage.setMobileNo("9885647026");
		postpaidAccountPage.clickSubmit();
	}

	@Then("^display his/her postpaid account details$")
	public void display_his_her_postpaid_account_details() throws Throwable {
		String expectedTitle = "PostPaid Account Details";
		Assert.assertEquals(expectedTitle, driver.getTitle());
		driver.close();
		
	}

	@When("^User enter incorrect customer id$")
	public void user_enter_incorrect_customer_id() throws Throwable {
		postpaidAccountPage.setCustomerID("215");
		postpaidAccountPage.setMobileNo("9885647026");
		postpaidAccountPage.clickSubmit();
	}

	@Then("^display customer id not found error message$")
	public void display_customer_id_not_found_error_message() throws Throwable {
		String expectedError = "Customer not found for Customer ID: 215";
		String actualError = postpaidAccountPage.getErrorMessage();
		Assert.assertEquals(expectedError, actualError);
	}

	@When("^User enters incorrect mobile number$")
	public void user_enters_incorrect_mobile_number() throws Throwable {
		postpaidAccountPage.setCustomerID("1002");
		postpaidAccountPage.setMobileNo("547");
		postpaidAccountPage.clickSubmit();
	}

	@Then("^display postpaid account not found error message$")
	public void display_postpaid_account_not_found_error_message() throws Throwable {
		String expectedError = "PostpaidAccount not found for Mobile Number:547";
		String actualError = postpaidAccountPage.getErrorMessage();
		Assert.assertEquals(expectedError, actualError);
		driver.close();
	}
}

package com.cg.mobilbilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PostpaidAccountBillDetailsPage {
	@FindBy(how = How.CLASS_NAME, name = "customerID")
	private WebElement customerID;
	@FindBy(how = How.CLASS_NAME, name = "mobileNo")
	private WebElement mobileNo;
	@FindBy(how = How.CLASS_NAME, name = "submit")
	private WebElement button;
	@FindBy(how = How.ID, id = "error")
	private WebElement errorMessage;
	
	public void clickSubmit() {
		this.button.click();
	}

	public String getErrorMessage() {
		return this.errorMessage.getText();
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
}
